//
//  StyliticsData.h
//  StyliticsData
//
//  Created by Hrithik Kesharwani on 13/04/22.
//

#import <Foundation/Foundation.h>

//! Project version number for StyliticsData.
FOUNDATION_EXPORT double StyliticsDataVersionNumber;

//! Project version string for StyliticsData.
FOUNDATION_EXPORT const unsigned char StyliticsDataVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StyliticsData/PublicHeader.h>


